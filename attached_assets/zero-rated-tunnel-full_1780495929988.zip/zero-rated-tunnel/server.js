const http = require("http");
const httpProxy = require("http-proxy");
const url = require("url");

// --- KONFIGURASI PENTING ---
// Ganti dengan domain zero-rated yang ingin Anda gunakan untuk spoofing.
// Berdasarkan payload Anda, contohnya adalah 'jupiter-mw.xlsmart.co.id' atau 'www.xl.co.id'.
// Pilih salah satu yang paling mungkin diakui sebagai zero-rated oleh operator.
const ZERO_RATED_DOMAIN = "jupiter-mw.xlsmart.co.id"; 

// Ganti dengan port yang akan didengarkan oleh server proxy ini.
const PROXY_PORT = 8080;

// --- AKHIR KONFIGURASI ---

// Buat instance proxy HTTP
const proxy = httpProxy.createProxyServer({});

// Tangani error proxy
proxy.on("error", (err, req, res) => {
    console.error("Proxy error:", err);
    if (res.writeHead) {
        res.writeHead(500, {
            "Content-Type": "text/plain"
        });
        res.end("Something went wrong with the proxy.");
    } else {
        console.error("Response object is not writable for error handling.");
    }
});

// Tangani permintaan HTTP
const server = http.createServer((req, res) => {
    console.log(`Incoming HTTP request: ${req.method} ${req.url}`);

    // Parse URL untuk mendapatkan target video yang sebenarnya dari parameter 'url'
    const parsedUrl = url.parse(req.url, true);
    const targetVideoUrl = parsedUrl.query.url; // Ambil URL video dari query parameter

    if (!targetVideoUrl) {
        // Jika tidak ada target video, layani file statis atau berikan pesan error
        if (req.url === "/") {
            // Untuk menyajikan index.html dari folder public
            const fs = require("fs");
            const path = require("path");
            const filePath = path.join(__dirname, "public", "index.html");
            fs.readFile(filePath, (err, data) => {
                if (err) {
                    res.writeHead(500);
                    return res.end("Error loading index.html");
                }
                res.writeHead(200, { "Content-Type": "text/html" });
                res.end(data);
            });
            return;
        }
        res.writeHead(400, { "Content-Type": "text/plain" });
        return res.end("Missing 'url' query parameter for video streaming.");
    }

    // Modifikasi header Host untuk spoofing zero-rated domain
    req.headers["Host"] = ZERO_RATED_DOMAIN;
    // Hapus header yang mungkin menyebabkan masalah atau identifikasi asli
    delete req.headers["x-forwarded-for"];
    delete req.headers["x-real-ip"];
    delete req.headers["via"];

    // Log header yang dimodifikasi (opsional, untuk debugging)
    // console.log('Modified HTTP Headers:', req.headers);

    // Teruskan permintaan ke target API video yang sebenarnya
    // Pastikan targetVideoUrl adalah URL yang valid (misal: http://example.com/video.mp4)
    try {
        const targetParsed = new URL(targetVideoUrl);
        proxy.web(req, res, { target: targetParsed.origin });
    } catch (e) {
        res.writeHead(400, { "Content-Type": "text/plain" });
        res.end("Invalid target video URL provided.");
    }
});

// Tangani upgrade WebSocket (jika API video menggunakan WebSocket)
server.on("upgrade", (req, socket, head) => {
    console.log(`Incoming WebSocket upgrade request: ${req.url}`);

    const parsedUrl = url.parse(req.url, true);
    const targetVideoUrl = parsedUrl.query.url; // Ambil URL video dari query parameter

    if (!targetVideoUrl) {
        socket.destroy();
        return;
    }

    // Modifikasi header Host untuk spoofing zero-rated domain pada WebSocket
    req.headers["Host"] = ZERO_RATED_DOMAIN;
    // Hapus header yang mungkin menyebabkan masalah atau identifikasi asli
    delete req.headers["x-forwarded-for"];
    delete req.headers["x-real-ip"];
    delete req.headers["via"];

    // Log header yang dimodifikasi (opsional, untuk debugging)
    // console.log('Modified WebSocket Headers:', req.headers);

    // Teruskan permintaan upgrade WebSocket ke target API video yang sebenarnya
    try {
        const targetParsed = new URL(targetVideoUrl);
        proxy.ws(req, socket, head, { target: targetParsed.origin });
    } catch (e) {
        socket.destroy();
    }
});

server.listen(PROXY_PORT, () => {
    console.log(`Server tunneling berjalan di http://localhost:${PROXY_PORT}`);
    console.log(`Semua lalu lintas akan di-proxy melalui domain zero-rated: ${ZERO_RATED_DOMAIN}`);
    console.log("PASTIKAN ANDA MENGGANTI ZERO_RATED_DOMAIN DENGAN NILAI YANG BENAR!");
    console.log("Untuk mengakses website, buka http://localhost:" + PROXY_PORT);
});

// --- CATATAN PENTING ---
// 1. Payload curl yang Anda berikan mengandung karakter non-standar seperti [crlf] dan [split]
//    yang tidak dapat diimplementasikan secara langsung oleh server HTTP/WebSocket standar.
//    Implementasi ini berfokus pada manipulasi header Host untuk spoofing.
// 2. Keberhasilan teknik ini sangat bergantung pada bagaimana operator seluler mendeteksi
//    dan memproses lalu lintas zero-rated. Tidak ada jaminan 100% bahwa ini akan bekerja
//    atau akan tetap bekerja di masa mendatang.
// 3. Penggunaan teknik ini untuk mengelabui sistem penagihan operator dapat melanggar
//    Ketentuan Layanan (ToS) operator dan berpotensi memiliki konsekuensi hukum.
//    Gunakan dengan risiko Anda sendiri.
// 4. Untuk video streaming, pastikan target API video mendukung HTTP streaming atau WebSocket
//    yang dapat di-proxy dengan baik.
// 5. Header 'authorization' dan 'Cookie' dari payload asli akan diteruskan jika ada
//    dari permintaan klien ke proxy, dan dari proxy ke target API video.
